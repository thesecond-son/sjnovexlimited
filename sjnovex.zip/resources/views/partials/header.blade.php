<header class="site-header">

    <div class="site-header__inner">

        {{-- Brand --}}
        <div class="site-header__brand">

            <a
                href="{{ route('home') }}"
                class="site-header__logo-link"
            >

                @if($settings->logo_path)

                    <img
                        src="{{ asset('storage/' . $settings->logo_path) }}"
                        alt="{{ $settings->business_name }} logo"
                        class="site-header__logo"
                    >

                @else

                    <div
                        class="site-header__logo-placeholder"
                        aria-label="Logo placeholder"
                    >
                        <span>
                            YOUR<br>LOGO
                        </span>
                    </div>

                @endif

            </a>


            <a
                href="{{ route('home') }}"
                class="site-header__brand-name"
            >

                {{ $settings->business_name }}

                <small>
                    LOGISTICS &amp; SUPPLY
                </small>

            </a>

        </div>


        {{-- Navigation --}}
        <nav
            class="site-header__nav"
            aria-label="Main navigation"
        >

            <a
                href="{{ route('home') }}"
                @class([
                    'is-active' => request()->routeIs('home')
                ])
            >
                Home
            </a>

            <a
                href="{{ route('about') }}"
                @class([
                    'is-active' => request()->routeIs('about')
                ])
            >
                About
            </a>

            <a
                href="{{ route('services') }}"
                @class([
                    'is-active' => request()->routeIs('services')
                ])
            >
                Services
            </a>

            <a
                href="{{ route('contact') }}"
                @class([
                    'is-active' => request()->routeIs('contact')
                ])
            >
                Contact
            </a>

        </nav>


        {{-- WhatsApp CTA --}}
        <a
            class="site-header__cta"
            href="https://wa.me/{{ $settings->whatsapp_number }}?text={{ urlencode($settings->whatsapp_default_message) }}"
            target="_blank"
            rel="noopener"
        >

            <svg
                viewBox="0 0 24 24"
                fill="currentColor"
                aria-hidden="true"
            >
                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2 22l5.29-1.39a9.9 9.9 0 0 0 4.75 1.21h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2zm0 18.02h-.01a8.1 8.1 0 0 1-4.13-1.13l-.3-.18-3.14.82.84-3.06-.19-.31a8.11 8.11 0 0 1-1.24-4.34c0-4.49 3.65-8.14 8.15-8.14 4.49 0 8.14 3.65 8.14 8.14 0 4.49-3.65 8.2-8.12 8.2zm4.46-6.1c-.24-.12-1.44-.71-1.67-.79-.22-.08-.39-.12-.55.12-.16.24-.63.79-.78.95-.14.16-.28.18-.53.06-.24-.12-1.02-.38-1.95-1.21-.72-.64-1.2-1.44-1.35-1.68-.14-.24-.02-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.55-1.32-.75-1.81-.2-.48-.4-.41-.55-.42h-.47c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.13 3.64.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.44-.59 1.64-1.16.2-.57.2-1.06.14-1.16-.06-.1-.22-.16-.46-.28z"/>
            </svg>

            <span class="site-header__cta-long">
                Chat on WhatsApp
            </span>

            <span class="site-header__cta-short">
                WhatsApp
            </span>

        </a>

    </div>

</header>