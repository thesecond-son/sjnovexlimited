<?php

namespace App\Filament\Resources\ProcessSteps;

use App\Filament\Resources\ProcessSteps\Pages\CreateProcessStep;
use App\Filament\Resources\ProcessSteps\Pages\EditProcessStep;
use App\Filament\Resources\ProcessSteps\Pages\ListProcessSteps;
use App\Filament\Resources\ProcessSteps\Pages\ViewProcessStep;
use App\Filament\Resources\ProcessSteps\Schemas\ProcessStepForm;
use App\Filament\Resources\ProcessSteps\Schemas\ProcessStepInfolist;
use App\Filament\Resources\ProcessSteps\Tables\ProcessStepsTable;
use App\Models\ProcessStep;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class ProcessStepResource extends Resource
{
    protected static ?string $model = ProcessStep::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedRectangleStack;

    protected static ?string $recordTitleAttribute = 'name';

    public static function form(Schema $schema): Schema
    {
        return ProcessStepForm::configure($schema);
    }

    public static function infolist(Schema $schema): Schema
    {
        return ProcessStepInfolist::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return ProcessStepsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListProcessSteps::route('/'),
            'create' => CreateProcessStep::route('/create'),
            'view' => ViewProcessStep::route('/{record}'),
            'edit' => EditProcessStep::route('/{record}/edit'),
        ];
    }
}
